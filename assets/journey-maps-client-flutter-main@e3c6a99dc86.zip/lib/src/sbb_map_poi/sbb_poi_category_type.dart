// These are given by ROKAS, hence we ignore lint warnings.
//ignore_for_file: constant_identifier_names
enum SBBPoiCategoryType {
  bike_parking,
  park_rail,
  bike_sharing,
  car_sharing,
  p2p_car_sharing,
  on_demand,
}
