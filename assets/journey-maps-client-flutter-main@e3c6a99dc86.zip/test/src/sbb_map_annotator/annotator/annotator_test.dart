import 'package:maplibre_gl/maplibre_gl.dart';
import 'package:mockito/annotations.dart';

@GenerateNiceMocks([
  MockSpec<MapLibreMapController>(),
])
void main() {}
